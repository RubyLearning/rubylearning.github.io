# ws1.rb
require 'net/http'

APPLICATION_ID = 'XIM4jgrV34GXdnMQfjYVcfY6YIMvb4FrOoBmcxAMHrVWrPPte0QDpYgieP5jZKFuCsL9'
YAHOO_WEB_SERVICE_SEARCH_URL = 'http://search.yahooapis.com/WebSearchService/V1/webSearch'
query = 'Satish Talim'
results_limit = 10
url = "#{YAHOO_WEB_SERVICE_SEARCH_URL}?appid=#{APPLICATION_ID}&query=#{URI.encode(query)}&results=#{results_limit}"
begin
  xml_result_set = Net::HTTP.get_response(URI.parse(url))
rescue Exception => e
  puts 'Connection error: ' + e.message
end
print xml_result_set.body
print xml_result_set.to_s + "\n"