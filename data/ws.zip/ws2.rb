# ws2.rb
require 'net/http'

APPLICATION_ID = 'XIM4jgrV34GXdnMQfjYVcfY6YIMvb4FrOoBmcxAMHrVWrPPte0QDpYgieP5jZKFuCsL9'
YAHOO_WEB_SERVICE_SEARCH_URL = 'http://search.yahooapis.com/WebSearchService/V1/webSearch'
query = 'Satish Talim'
results_limit = 10
url  = YAHOO_WEB_SERVICE_SEARCH_URL

post_args     = {
  'appid'   => APPLICATION_ID,
  'query'   => query,
  'results' => results_limit,
}

begin
  response, xml_result_set = Net::HTTP.post_form(URI.parse(url), post_args)
rescue Exception => e
  puts 'Connection error: ' + e.message
end
puts xml_result_set
puts response