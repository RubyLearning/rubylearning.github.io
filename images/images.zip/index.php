<?php
header("Location: http://rubylearning.com/");
exit();
?>